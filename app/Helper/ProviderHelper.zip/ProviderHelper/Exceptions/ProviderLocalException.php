<?php


namespace Zkood\DeliveryPortal\Exceptions;

class  ProviderLocalException extends ProviderException
{
}
