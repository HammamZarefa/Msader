<?php


namespace Zkood\DeliveryPortal\Exceptions;

class  ProviderRemoteException extends ProviderException
{
}
