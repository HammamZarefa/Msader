<?php

namespace App\Helper\ProviderHelper\Provider\SmsActivate;

class GetOrderStatus extends AbstractSmsActivateOperation
{

}
