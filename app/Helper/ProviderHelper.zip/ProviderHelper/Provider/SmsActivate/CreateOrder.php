<?php

namespace App\Helper\ProviderHelper\Provider\SmsActivate;

class CreateOrder extends AbstractSmsActivateOperation
{

}
