<?php
//
//namespace App\Helper\ProviderHelper\Facades;
//
////use Illuminate\Support\Facades\Facade;
//
//class SmsActivate extends Facade
//{
////    protected static function getFacadeAccessor()
////    {
////        return 'smsactivate';
////    }
//}
